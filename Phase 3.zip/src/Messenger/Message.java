package Messenger;

public class Message implements Message_interface {
    long Max_characters;

    public static boolean Send_message(String friendname)
    {

    }

    public static boolean Send_to_group(String groupname)
    {

    }

    @Override
    public void displayMessage() {

    }

    @Override
    public void choosereciever() {

    }
}
