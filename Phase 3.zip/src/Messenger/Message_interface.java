package Messenger;

public interface Message_interface {
    public void displayMessage();
    public void choosereciever();
}
