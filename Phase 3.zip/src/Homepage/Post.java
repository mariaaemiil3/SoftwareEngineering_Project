package Homepage;

public class Post implements Post_interface {
    String privacy, text;

    public static void write_post(String Privacy, String text)
    {

    }

    public static void share_post()
    {

    }

    public static void like_post()
    {

    }

    public static boolean checkaccessibility()
    {

    }

    @Override
    public void display_my_posts() {

    }

    @Override
    public void view_likes() {

    }

    @Override
    public void view_comments() {

    }
}
