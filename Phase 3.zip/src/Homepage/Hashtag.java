package Homepage;

public class Hashtag implements Hashtag_interface {
    String name;
    long Num_Of_Repeat;

    public static void search_hashtag(String hashtagname)
    {

    }

    public static void Write_hashtag()
    {

    }

    public static void checkhashashtag()
    {

    }

    @Override
    public void display_results() {

    }
}
