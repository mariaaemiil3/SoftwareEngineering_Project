package Homepage;

public interface Hashtag_interface {
    public void display_results();
}
