package Homepage;

public interface Post_interface {
    public void display_my_posts();
    public void view_likes();
    public void view_comments();
}
