package Social;

public class Page implements Page_interface{
    String name;

    public static void Create_page(String pagename)
    {

    }

    public static void Like_page(String pagename)
    {

    }

    public static void Delete_page(String pagename)
    {

    }

    public static void setadmin(String username)
    {

    }

    @Override
    public void Enter_name(String name) {

    }

    @Override
    public void select_privacy() {

    }

    @Override
    public void display_posts() {

    }

    @Override
    public void display_likes() {

    }
}
