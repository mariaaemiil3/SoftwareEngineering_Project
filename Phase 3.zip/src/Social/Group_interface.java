package Social;

public interface Group_interface {
    public void Display_user_list();
    public void Display_sucess_message();
}
