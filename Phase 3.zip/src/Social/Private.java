package Social;

public class Private extends Group {
    String name;
}
