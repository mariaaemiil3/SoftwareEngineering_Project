package Social;

public interface Page_interface {
    public void Enter_name(String name);
    public void select_privacy();
    public void display_posts();
    public void display_likes();
}
