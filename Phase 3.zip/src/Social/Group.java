package Social;

public class Group implements Group_interface{
    String name,description;

    public static void change_privacy()
    {

    }

    public static void add_people()
    {

    }

    public static void addtogroupmembers(String adduser)
    {

    }

    public static void joinrequest(String username)
    {

    }

    public static void viewmembers()
    {

    }

    @Override
    public void Display_user_list() {

    }

    @Override
    public void Display_sucess_message() {

    }
}
