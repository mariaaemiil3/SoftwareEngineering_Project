package Social;

public class Public extends Group {
    String name;
}
