package Model;

public class CreditCardStrategy implements PaymentStrategy {

    private String name;
    private String cardNum;
    //private String dateOfExpiry;

    CreditCardStrategy(String Name, String CardNum/*, String DateOfExpiry*/)
    {
        this.name = Name;
        this.cardNum = CardNum;
        //this.dateOfExpiry = DateOfExpiry;
    }
    @Override
    public void pay(int payment) {

    }
}
