package Model;

public interface User_interface {
    public boolean addFriend(String name);
    public boolean acceptFriend(boolean response,String name);
    //public boolean searchaFriend(String name);
    public boolean removeFriend(String name);

    //public boolean Login(String username, String Pass);
    public boolean setProfilePicture();
    public void displayFriendList();
    public void selectprivacy();

}
