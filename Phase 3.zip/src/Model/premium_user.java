package Model;

public class premium_user extends User {
    String name;
    double payment;
    final int ADSnum = 10;
    String PaymentMethod;
    boolean checkPremium;

    public static double checkpayments()
    {

    }

    public static void addNewAd()
    {

    }

}
