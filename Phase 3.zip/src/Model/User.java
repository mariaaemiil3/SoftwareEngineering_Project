package Model;

import java.util.ArrayList;
import java.util.Scanner;

public class User implements User_interface {
    public static String Name, Email;
    private static String Password,Country,Gender,DateOfBirth;
    public static ArrayList <User> db = new ArrayList<>();
    private static User Instance;

    public static ArrayList<User>  friendlist = new ArrayList<>();
    public static ArrayList<String> Users = new ArrayList<String>();
    String name;

    private User()
    {
        User u = User.getInstance();
        name = u.Name;
        for (int i = 0; i < u.db.size(); i++) {
            Users.add(u.db.get(i).Name);
        }
    }

    public static User getInstance()
    {
        if(Instance == null)
        {
            Instance = new User();
        }
        return Instance;
    }
   /* public static boolean AcceptFriendReq(boolean response,String friendName)
    {
        if(response == true)
        {
            addinhisfriendlist(friendName);
            return true;
        }else{
            return false;
        }
    }*/

    public static void change_name(String name)
    {

    }

    public static void change_photo()
    {

    }

    public static void Logout()
    {

    }

    public static void searchresults()
    {

    }

  /*  public static boolean login(String name,String password)
    {
        for(int i=0; i<db.size(); i++)
        {
            if(!name.equals(db.get(i).Email) || !name.equals(db.get(i).Name))
            {
                return false;
            }
            else{
                if(!password.equals(db.get(i).Password))
                {
                    return false;
                }
            }
        }
        return true;
    }*/




    public static void search(String searchedstring)
    {

    }

    public static boolean SearchFriend(String friendName)
    {
        for(int i=0; i< Users.size(); i++)
        {
            if(friendName.equals(Users.get(i)))
            {
                return true;
            }
        }
        return false;
    }

  /*  public static boolean Add_friend(String friendname)
    {
        boolean searchResult = SearchFriend(friendname);
        if(!searchResult)
        {
            System.out.println("Friend not found!");
            return false;
        }else {
            System.out.println("Friend added successfully");
            return true;
        }
    }*/

    public static void Remove_friend(String friendname)
    {

    }



    /**Normal_user() {
        User u = User.getInstance();
        name = u.Name;
        for (int i = 0; i < u.db.size(); i++) {
            Users.add(u.db.get(i).Name);
        }
    }**/



    public static void addinhisfriendlist(String friendName)
    {
        User user= new User();
        user.Name = friendName;
        friendlist.add(user);
    }

    public static void pay(PaymentStrategy P,int payment)
    {
        P.pay(payment);
    }

    public static ArrayList <User> displayfriendlist()
    {
        return friendlist;
    }

    @Override
    public boolean addFriend(String name) {
        boolean searchResult = SearchFriend(name);
        if(!searchResult)
        {
            System.out.println("Friend not found!");
            return false;
        }else {
            System.out.println("Friend added successfully");
            return true;
        }
    }

    @Override
    public boolean acceptFriend(boolean response,String name) {
        if(response == true)
        {
            addinhisfriendlist(name);
            return true;
        }else{
            return false;
        }
    }



    @Override
    public boolean removeFriend(String name) {
        return false;
    }



    @Override
    public boolean setProfilePicture() {
        return false;
    }

    @Override
    public void displayFriendList() {

    }

    @Override
    public void selectprivacy() {

    }
}
