package Model;

import java.util.ArrayList;
import java.util.Scanner;

public class UserController {
    public static String Name, Email;
    private static String Password,Country,Gender,DateOfBirth;
    public static ArrayList<User> db = new ArrayList<>();
    private static User Instance;

    public static ArrayList<User>  friendlist = new ArrayList<>();
    public static ArrayList<String> Users = new ArrayList<String>();

    private static boolean checkValidEmail(String Email) {
        for(int i=0; i<db.size(); i++)
        {
            if(Email.equals(db.get(i).Email))
            {
                return true;
            }
        }
        return false;
    }

    public static void register(String name,String password,String email,String gender,String country,String dateOfBirth)
    {
        Scanner in = new Scanner(System.in);
        boolean valid = false;
        String splitt[] = new String[4];

        Name = name;
        while(password.length() < 8 && (!password.contains("1") || !password.contains("2") || !password.contains("3") || !password.contains("4")
                || !password.contains("5") || !password.contains("6") || !password.contains("7") || !password.contains("8") || !password.contains("9")))
        {
            System.out.println("Please enter a password of 8 characters or more and must contains at least 1 number");
            password = in.next();
        }
        Password = password;
        valid = checkValidEmail(email);
        while(!email.contains("@") || !valid)
        {
            System.out.println("Please enter a valid email");
            email = in.next();
        }
        Email = email;
        while(gender != "male" || gender != "female")
        {
            System.out.println("Please enter a valid gender");
            gender = in.next();
        }
        Gender = gender;
        Country = country;
        splitt = dateOfBirth.split("/");
        while(splitt.length > 3){
            System.out.println("Please enter a valid birth date");
            dateOfBirth = in.next();
            splitt = dateOfBirth.split("/");
        }
        DateOfBirth = dateOfBirth;
    }

    public static boolean UpgradeToPremium(String payMethod) {
        Scanner in = new Scanner(System.in);
        PaymentStrategy p;
        if (payMethod == "Credit Card") {
            System.out.println("Enter Name:");
            String name = in.next();
            System.out.println("Enter Credit Card number:");
            String cardNum = in.next();
            p = new CreditCardStrategy(name, cardNum);
        } else if (payMethod == "PayPal") {
            System.out.println("Enter your Email ID:");
            String emailid = in.next();
            System.out.println("Enter your Password:");
            String password = in.next();
            p = new PayPalStrategy(emailid, password);
        }

        /**
         if (User.checkpayments() < 99.0) {
         return false;
         } else {
         return true;
         }**/

    }

    @Override
    public boolean searchaFriend(String name) {
        return false;
    }

    public static boolean check_premium()
    {

    }

    @Override

    public boolean Login(String username, String Pass) {
        for(int i=0; i<db.size(); i++)
        {
            if(!username.equals(db.get(i).Email) || !username.equals(db.get(i).Name))
            {
                return false;
            }
            else{
                if(!Pass.equals(db.get(i).Password))
                {
                    return false;
                }
            }
        }
        return true;
    }
}
