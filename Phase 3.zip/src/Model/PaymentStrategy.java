package Model;

public interface PaymentStrategy {
    public abstract void pay(int payment);
}
