package Model;

public class Main {
    public static void main(String[] args) {
        // write your code here
        User u = User.getInstance();
    }
}
