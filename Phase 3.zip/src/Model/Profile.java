package Model;

public class Profile {
    String Username, password, about;

    public static void Showinfo()
    {

    }

    public static void Change_setting()
    {

    }

    public static void change_privacy()
    {

    }

    public static void createprofile(String username, String pass)
    {

    }


}
