package Model;

public class PayPalStrategy implements PaymentStrategy {

    private String emailid,password;

    PayPalStrategy(String emailid,String password)
    {
        this.emailid = emailid;
        this.password = password;
    }

    @Override
    public void pay(int payment) {

    }
}
